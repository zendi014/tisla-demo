<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; {{ date("Y") }} <div class="bullet"></div> Developed by <a href="https://youtube.com/indokoding" target="_blank">IndoKoding</a> and Theme by <a href="https://getstisla.com/" target="_blank">Stisla</a>
    </div>
    <div class="footer-right">
    2.3.0
    </div>
</footer>