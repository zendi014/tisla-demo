<?php

return [
    'btn_create_label' => 'Create',
    'btn_edit_label' => 'Edit',
    'btn_show_label' => 'Show',
    'btn_delete_label' => 'Delete',
    'btn_update_label' => 'Update',
    'action_label' => 'Action',
    'btn_search_label' => 'Search',

    'validation_error_message' => 'There are some problems with your input.',

    'menu_account_label' => 'Account',

    'invalid_date_range' => 'Invalid date range',
];